%scriptLoadPaperData
clear
load('October Data.mat')
